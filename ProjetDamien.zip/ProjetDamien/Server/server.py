import discord # type: ignore
from discord.ext import commands # type: ignore
import uuid


TOKEN = 'MTMxOTcyMjQ5MTMxMjA4Mjk3NA.GzX5Ez.310riHf5CrD0my2V-tDUSfg3_0R6yTWTT4vqJk'

# ID des channels
CHANNEL_ID_controller = 1320383746133852180  # Remplacez par l'ID du channel 1
CHANNEL_ID_commands = 1311324272354131998
CHANNEL_ID_response = 1311325762351271946

NODE_ID = 1

# Intents pour écouter les messages
intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} est connecté !')

@bot.event
async def on_message(message):
    # Empêche le bot de répondre à ses propres messages
    if message.author == bot.user:
        return

    # Si le message vient du channel ID1, on l'envoie dans ID2
    if message.channel.id == CHANNEL_ID_controller:
        channel_cmds = bot.get_channel(CHANNEL_ID_commands)
        if channel_cmds:
            if len(message.content.split(" ")) > 1 and message.content.split(" ")[0].isdigit():
                node_id, command = message.content.split(" ", 1)
                formatted_instruction = f"{node_id} {uuid.uuid4()} {command}"
            else:
                formatted_instruction = f"{NODE_ID} {uuid.uuid4()} {message.content}"
            print(formatted_instruction)
            await channel_cmds.send(formatted_instruction)

    # Si le message vient du channel ID3, on l'envoie dans ID1
    elif message.channel.id == CHANNEL_ID_response:
        channel1 = bot.get_channel(CHANNEL_ID_controller)
        if channel1:
            await channel1.send(message.content)

    # Permet aux commandes du bot de fonctionner
    await bot.process_commands(message)

# Lance le bot
bot.run(TOKEN)
