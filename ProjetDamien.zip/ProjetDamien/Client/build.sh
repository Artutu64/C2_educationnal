go mod tidy
go build main.go
echo "Fichier créé !"