package client

import (
	messages "AnalVul/packages"
	"fmt"
	"io"
	"math/rand"
	"net"
	"strconv"
	"time"
)

func GetPrivateIP() (string, error) {
	// Établir une connexion fictive à une adresse publique
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err != nil {
		return "", fmt.Errorf("impossible de déterminer l'adresse IP privée: %v", err)
	}
	defer conn.Close()

	// Récupérer l'adresse locale associée à la connexion
	localAddr := conn.LocalAddr().(*net.UDPAddr)

	return localAddr.IP.String(), nil
}

func (this *Client) uploadError(conn net.Conn) {
	msg := &messages.ProtoMessage{
		FetchMessage: &messages.ProtoMessage_FileTransferError{
			FileTransferError: &messages.FileTransferError{
				Error: "Erreur lors de la création du listener TCP",
			},
		},
	}
	go this.sendMessage(conn, msg, false, nil)
	return
}

func (this *Client) PrepareForFileTransfer(fileName string, SIZE int, toRespond net.Conn, uuid string) {
	rand.Seed(time.Now().UnixNano())
	minPort := 10000
	maxPort := 50000
	port := rand.Intn(maxPort-minPort+1) + minPort
	_addr, err1 := GetPrivateIP()
	if err1 != nil {
		go this.uploadError(toRespond)
		return
	}
	listener, err := net.Listen("tcp", "0.0.0.0:"+strconv.Itoa(port))
	if err != nil {
		go this.uploadError(toRespond)
		return
	}
	go this.SendFileTransferResponse(_addr+":"+strconv.Itoa(port), toRespond)
	Newconn, err := listener.Accept()
	if err != nil {
		return
	}

	// Lire N bytes de la connexion
	buffer := make([]byte, SIZE)
	_, err = io.ReadFull(Newconn, buffer)
	if err != nil {
		return
	}
	Newconn.Close()
	listener.Close()
	go this.UploadFileContent(fileName, buffer, uuid)
}

func (this *Client) SendFileTransferResponse(addr string, toRespond net.Conn) {
	msg := &messages.ProtoMessage{
		FetchMessage: &messages.ProtoMessage_FileTransferResponse{
			FileTransferResponse: &messages.FileTransferResponse{
				Addr: addr,
			},
		},
	}
	this.sendMessage(toRespond, msg, false, nil)
}

func (this *Client) SendFileToListener(addr string, content []byte) {
	conn, err := net.Dial("tcp", addr)
	if conn != nil || err == nil {
		conn.Write(content)
	}
	conn.Close()
}
