package messages

import (
	"AnalVul/Constantes"
	"AnalVul/chiffrement"
	"encoding/binary"
	"errors"
	"google.golang.org/protobuf/proto"
	"io"
	"log"
	"net"
)

// ReceiveProtoMessageMessage reçoit un message marshallé Protobuf sur une
// connexion conn et le désérialise après l'avoir déchiffré.
// Cette fonction doit être appelée depuis une seule goroutine à la fois.
func ReceiveProtoMessageMessage(conn net.Conn) (message *ProtoMessage, err error) {
	// D'abord, obtenir le nombre d'octets à recevoir
	bs := make([]byte, Constantes.I64SIZE)
	length, err := conn.Read(bs)
	if err != nil {
		if err != io.EOF {
			log.Printf("ReceiveProtoMessageMessage() erreur de lecture: %s\n", err)
		}
		return
	}
	if length != Constantes.I64SIZE {
		log.Printf("ReceiveProtoMessageMessage() erreur de taille de paquet: %d\n", length)
		return
	}

	// La taille des données chiffrées
	numBytes := int(binary.BigEndian.Uint64(bs))

	// Lire les données chiffrées
	data := make([]byte, numBytes)
	length, err = conn.Read(data)
	if err != nil {
		if err != io.EOF {
			log.Printf("ReceiveProtoMessage() erreur de lecture: %s\n", err)
		}
		return
	}
	if length != numBytes {
		log.Printf("ReceiveProtoMessage() erreur de taille de paquet: %d\n", length)
		return
	}

	// Déchiffrer les données reçues
	decryptedData, err := chiffrement.DecryptAES(data)
	if err != nil {
		log.Printf("Erreur lors du déchiffrement AES %s\n", err)
		return
	}

	// Désérialiser le message protobuf
	message = &ProtoMessage{}
	err = proto.Unmarshal(decryptedData, message)
	if err != nil {
		log.Printf("ReceiveProtoMessage() erreur lors de l'unmarshal du message %v, erreur: %s\n",
			data, err)
		return
	}
	if Constantes.RECEIVE_LOG {
		log.Printf("ReceiveProtoMessage(): message reçu %s (%v), %d depuis %s\n",
			message, decryptedData, length, conn.RemoteAddr().String())
	}
	return
}

// SendProtoMessage marshalise et envoie un message protobuf sur
// une connexion conn après l'avoir chiffré.
func SendProtoMessage(conn net.Conn, message *ProtoMessage) (err error) {
	// Marshalisation du message protobuf
	if message == nil {
		return
	}
	data, err := proto.Marshal(message)
	if err != nil {
		log.Println("SendProtoMessage() Impossible de parser le message.", err)
		return err
	}

	// Chiffrement du message
	encryptedData, err := chiffrement.EncryptAES(data)
	if err != nil {
		log.Printf("Erreur lors du chiffrement du message %s\n", err)
		return
	}
	/*log.Printf("SendProtoMessage():   Chiffré %s (%v), %d à %s\n",
		message, data, len(data), conn.RemoteAddr().String())
	log.Printf("SendProtoMessage(): Déchiffré %s (%v), %d à %s\n",
		message, encryptedData, len(encryptedData), conn.RemoteAddr().String())*/

	// Envoyer la taille des données
	bs := make([]byte, Constantes.I64SIZE)
	binary.BigEndian.PutUint64(bs, uint64(len(encryptedData)))

	// Concaténer la taille et les données chiffrées
	msg := append(bs, encryptedData...)

	// Envoyer les données sur la connexion
	length, err := conn.Write(msg)
	if err != nil {
		log.Printf("SendProtoMessage(%v) erreur: %s\n", message, err)
	}
	if length != len(msg) {
		log.Println("SendProtoMessage() Écriture incomplète?")
		return errors.New("SendProtoMessage() Ecriture incomplete")
	}
	return
}
