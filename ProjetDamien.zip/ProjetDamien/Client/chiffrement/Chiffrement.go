package chiffrement

import (
	"AnalVul/Constantes"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"fmt"
)

// Padding des données (PKCS7)
func pad(data []byte, blockSize int) []byte {
	padding := blockSize - len(data)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(data, padText...)
}

// Suppression du padding (PKCS7)
func unpad(data []byte) ([]byte, error) {
	length := len(data)
	if length == 0 {
		return nil, fmt.Errorf("données incorrectes")
	}
	padding := int(data[length-1])
	if padding > length {
		return nil, fmt.Errorf("padding incorrect")
	}
	return data[:length-padding], nil
}

// EncryptAES chiffre les données avec AES en mode CBC
func EncryptAES(plaintext []byte) ([]byte, error) {
	// Création du bloc AES
	block, err := aes.NewCipher(Constantes.KEY)
	if err != nil {
		return nil, err
	}

	// Ajout du padding
	plaintext = pad(plaintext, aes.BlockSize)

	// Chiffrement avec CBC
	ciphertext := make([]byte, len(plaintext))
	mode := cipher.NewCBCEncrypter(block, Constantes.IV)
	mode.CryptBlocks(ciphertext, plaintext)

	return ciphertext, nil
}

// DecryptAES déchiffre les données avec AES en mode CBC
func DecryptAES(ciphertext []byte) ([]byte, error) {
	// Création du bloc AES
	block, err := aes.NewCipher(Constantes.KEY)
	if err != nil {
		return nil, err
	}

	// Déchiffrement avec CBC
	plaintext := make([]byte, len(ciphertext))
	mode := cipher.NewCBCDecrypter(block, Constantes.IV)
	mode.CryptBlocks(plaintext, ciphertext)

	// Suppression du padding
	return unpad(plaintext)
}
