package main

import (
	"AnalVul/client"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
)

func main() {
	if len(os.Args) != 3 && len(os.Args) != 4 {
		fmt.Println("Usage: <executable> <id:int64> <port:string> (<ipv4:port> \"beacon\")")
		os.Exit(1)
	}

	idArg := os.Args[1]
	portArg := os.Args[2]
	addressArg := "127.0.0.0:50"
	if len(os.Args) == 4 {
		addressArg = os.Args[3]
	}

	id, err := strconv.ParseInt(idArg, 10, 64)
	if err != nil || id <= 0 {
		fmt.Println("Erreur: L'ID doit être un entier positif au format int64.")
		os.Exit(1)
	}

	port, err := strconv.Atoi(portArg)
	if err != nil || port <= 0 || port > 65535 {
		fmt.Println("Erreur: Le port doit être une chaîne représentant un entier entre 1 et 65535.")
		os.Exit(1)
	}

	addressParts := strings.Split(addressArg, ":")
	if len(addressParts) != 2 {
		fmt.Println("Erreur: L'adresse doit être au format IPv4:port.")
		os.Exit(1)
	}

	ip := addressParts[0]
	ipPort := addressParts[1]

	if net.ParseIP(ip) == nil {
		fmt.Println("Erreur: L'adresse IPv4 est invalide.")
		os.Exit(1)
	}

	ipPortNum, err := strconv.Atoi(ipPort)
	if err != nil || ipPortNum <= 0 || ipPortNum > 65535 {
		fmt.Println("Erreur: Le port dans l'adresse IPv4 est invalide.")
		os.Exit(1)
	}

	var wg sync.WaitGroup
	wg.Add(1)
	client.NewClient(id, "0.0.0.0:"+portArg, addressArg, wg)
	wg.Wait()
}
