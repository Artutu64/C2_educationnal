package Concurent

type Semaphore struct {
	ch chan struct{}
}

// Crée un nouveau sémaphore avec une capacité donnée
func NewSemaphore(capacity int) *Semaphore {
	return &Semaphore{
		ch: make(chan struct{}, capacity),
	}
}

// Acquire bloque jusqu'à ce qu'une ressource soit disponible
func (s *Semaphore) Acquire() {
	s.ch <- struct{}{} // Ajoute un élément dans le canal (prend une ressource)
}

// Release libère une ressource
func (s *Semaphore) Release() {
	<-s.ch // Supprime un élément du canal (libère une ressource)
}
