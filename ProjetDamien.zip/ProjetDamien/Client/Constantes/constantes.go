package Constantes

/*
VARIABLES LIEES AU CHIFFREMENT DE LA DONNEE:
*/
var KEY = []byte("exempledecleaesp") // 16 octets pour AES-128
var IV = []byte("vecteurinitconst")

/*
VARIABLES LIES AU BOT DISCORD:
*/
const CHANNEL_COMMANDS string = "1311324272354131998"
const CHANNEL_RETOUR string = "1311325762351271946"
const CHANNEL_NODES string = "1311324309175664650"
const TOKEN string = "MTMxMTMzNzQyNzY5MTkwMDkzOA.GGbMV3.epf7QUoM9TViVcbsU7nS6acv5zl5h9EAJF02Co"

/*
PROTOBUFF
*/
const RECEIVE_LOG bool = false
const I64SIZE int = 8
